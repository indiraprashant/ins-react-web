import React, { Fragment } from "react";
const AcademicPrograms = () => {
    return (
        <Fragment>
           <div className="className">
           <div className="container custom_spacing">
                    <h3 className="text-center subheadingM textPinkColor">Contact Us</h3>
                    <div className="row">
                        <div className="col-md-12">
                            <div className="map-responsive">
                                <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d17090.877717090894!2d73.74677980059982!3d18.60769872432542!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x362bf250d12307a7!2sIndira%20National%20School!5e0!3m2!1sen!2sin!4v1649916874233!5m2!1sen!2sin" width="600" height="450" style={{ border: "0" }} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                            </div>
                        </div>
                    </div>
                </div>
           </div>
        </Fragment>
    )
}
export default AcademicPrograms;